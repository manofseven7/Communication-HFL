"""Wait for the full experiment grid, then build strictly validated analyses."""
from pathlib import Path
import json,time,subprocess,sys,os,zipfile,hashlib
ROOT=Path(__file__).parent;os.chdir(ROOT);R=ROOT/'revision_results'
ENV=os.environ.copy();ENV.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
methods=['fedavg','fedprox','scaffold','fednova','fedkd','powersgd','qsgd','fedpaq','fedcom','topk','adaptive_topk','sign']
expected=[]
for ds in ['har','fashion']:
    for seed in range(42,47):
        expected += [R/f'{ds}_{m}_s{seed}.json' for m in methods]
        expected += [R/f'{ds}_proposed_nofs_s{seed}.json']
        if ds=='har':expected += [R/f'har_proposed_fs_s{seed}.json']
for seed in range(42,47):expected += [R/f'cifar_{m}_s{seed}.json' for m in ['fedavg','powersgd','qsgd','proposed']]
assert len(expected)==155
while True:
    ready=[]
    for p in expected:
        try:
            d=json.loads(p.read_text())
            if len(d.get('traj',[]))==(400 if p.name.startswith('cifar_') else 30):ready.append(p)
        except (OSError,json.JSONDecodeError):pass
    print(time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),'WAIT_FOR_COMPLETE_MAIN_GRID',len(ready),155,flush=True)
    if len(ready)==155:break
    time.sleep(30)
for folder,n in [('profile',24),('scalability',12),('fs_validation',9)]:
    records=[json.loads(p.read_text()) for p in (R/folder).glob('*.json')]
    if len(records)!=n:raise ValueError(f'Expected {n} complete auxiliary runs in {folder}')
    if folder=='fs_validation':
        if {(v['cfg']['seed'],v['cfg']['rho']) for v in records}!={(s,rho) for s in [42,43,44] for rho in [.9,.8,.7]}:raise ValueError('Validation seed/retention mismatch')
        if any(len(v['traj'])!=30 for v in records):raise ValueError('Incomplete validation trajectory')

def run(args,out):
    print('ANALYSIS_START',args,flush=True)
    with (ROOT/out).open('w') as log:subprocess.run([sys.executable]+args,env=ENV,stdout=log,stderr=subprocess.STDOUT,check=True)
    print('ANALYSIS_DONE',args[0],flush=True)
run(['scripts/revision_analysis.py','--results',str(R),'--out','revision_analysis'],'revision_statistics.log')
run(['scripts/revision_outputs.py','--results',str(R),'--out','revision_outputs','--stage','all'],'revision_outputs.log')
run(['scripts/summarize_auxiliary.py','profile','--root',str(R/'profile')],'revision_profile_summary.txt')
run(['scripts/summarize_auxiliary.py','scalability','--root',str(R/'scalability')],'revision_scalability_summary.txt')
completion=dict(completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),main_accuracy_runs=155,auxiliary_runs=45,total_experiment_runs=200,full_grid_and_analysis_complete=True,manuscript_submission_ready=False,remaining=['Integrate and review the complete CNN comparisons in manuscript and response','Deposit corrected source and outputs as a DOI-assigned version','Final clean/marked PDFs and consistency review'])
(ROOT/'revision_analysis_completion.json').write_text(json.dumps(completion,indent=2))
readme='''# Completed experiment data and analysis

All 200 experiment runs are complete and the strict five-seed analyses have passed.
This archive is not the final journal submission package. The manuscript/response
must still be integrated and reviewed, and the corrected code/output version
must be deposited with a version-specific DOI.

Measured_Results contains original seed-level JSON records, including complete
round trajectories. Analysis contains the strict paired statistics and figures.
Executed_Source is the molab source snapshot used by the runners. Its CLI uses
automatic per-round checkpoints and run locks; CIFAR presets select the GPU.
No raw dataset or large model checkpoint is included. Dataset source/checksum
provenance and runtime hardware/software metadata are retained. wall_time_s in
a resumed main run refers to the current process invocation; the separate
fresh-process one-round auxiliary timings are the reported runtime measurements.

The paired HAR warm-up trajectories are identical through round 5; activation
is in round 6. The six-comparison Holm family is explicit. All figures use actual
round-level data without smoothing, imputation or hand-set endpoints.
'''
entries={}
for p in R.rglob('*.json'):entries['Measured_Results/'+str(p.relative_to(R))]=p.read_bytes()
for folder in ['revision_analysis','revision_outputs']:
    for p in (ROOT/folder).rglob('*'):
        if p.is_file():entries['Analysis/'+str(p.relative_to(ROOT))]=p.read_bytes()
for p in ROOT.rglob('*.py'):
    if 'data' not in p.parts and '__pycache__' not in p.parts:entries['Executed_Source/'+str(p.relative_to(ROOT))]=p.read_bytes()
for p in ROOT.glob('cifar*.json'):entries['Provenance/'+p.name]=p.read_bytes()
entries['Provenance/revision_analysis_completion.json']=json.dumps(completion,indent=2).encode()
entries['README_Execution.md']=readme.encode()
if (ROOT/'LICENSE').exists():entries['LICENSE']=(ROOT/'LICENSE').read_bytes()
entries['SHA256SUMS.txt']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n' for k,v in sorted(entries.items())).encode()
target=ROOT/'HFL_Complete_Results_And_Analysis.zip'
with zipfile.ZipFile(str(target)+'.tmp','w',zipfile.ZIP_DEFLATED) as z:
    for name,data in entries.items():z.writestr(name,data)
os.replace(str(target)+'.tmp',target)
print('ALL_200_RUNS_AND_ANALYSIS_COMPLETE',target.stat().st_size,flush=True)
