import pathlib,urllib.request,hashlib,json,time,os,subprocess,signal
r=pathlib.Path(__file__).parent;os.chdir(r)
expected='c58f30108f718f92721af3b95e74349a'
original=r/'data/cifar-10-python.tar.gz'
if original.exists() and original.stat().st_size==170498071 and hashlib.md5(original.read_bytes()).hexdigest()==expected:
    print('DATA_ALREADY_VERIFIED',flush=True);raise SystemExit(0)
info=json.load(urllib.request.urlopen('https://huggingface.co/api/datasets/MIT-OL-AI-D/cifar-10-python',timeout=15))
sha=info['sha'];url=f'https://huggingface.co/datasets/MIT-OL-AI-D/cifar-10-python/resolve/{sha}/cifar-10-python.tar.gz'
print('PINNED_MIRROR',sha,flush=True)
tmp=r/'data/cifar-10-hf-verified.tar.gz';h=hashlib.md5();n=0;t0=time.monotonic()
with urllib.request.urlopen(url,timeout=15) as response,tmp.open('wb') as out:
    while True:
        b=response.read(1024*1024)
        if not b:break
        out.write(b);h.update(b);n+=len(b)
        if n%(20*1024*1024)==0:print('BYTES',n,flush=True)
        if n<5*1024*1024 and time.monotonic()-t0>30:raise RuntimeError('Alternative is slow; original download is retained')
if h.hexdigest()!=expected:raise ValueError('Checksum mismatch')
print('VERIFIED',n,'seconds',time.monotonic()-t0,flush=True)
if original.exists() and original.stat().st_size==170498071 and hashlib.md5(original.read_bytes()).hexdigest()==expected:
    print('ORIGINAL_COMPLETED_IN_PARALLEL',flush=True);raise SystemExit(0)
worker=int((r/'cifar.pid').read_text())
children=subprocess.run(['pgrep','-P',str(worker)],capture_output=True,text=True).stdout.split()
for pid in children:
    cmd=pathlib.Path(f'/proc/{pid}/cmdline').read_bytes()
    if b'run.py' in cmd and b'cifar' in cmd:os.kill(int(pid),signal.SIGTERM)
time.sleep(1);os.replace(tmp,original)
(r/'revision_results/cifar_download_provenance.json').write_text(json.dumps(dict(url=url,sha=sha,md5=expected,bytes=n),indent=2))
with (r/'cifar_grid.log').open('a') as f:p=subprocess.Popen([os.sys.executable,'-u','cifar_grid.py'],cwd=r,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
(r/'cifar.pid').write_text(str(p.pid));print('GPU_QUEUE_RESUMED',p.pid,flush=True)
