import os,sys,pathlib,subprocess,json,time,zipfile,platform
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
r=pathlib.Path(__file__).parent;os.chdir(r)
o=r/'revision_results';o.mkdir(exist_ok=True)
import torch,numpy,scipy,sklearn
meta=dict(python=sys.version,torch=torch.__version__,numpy=numpy.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,cpu=subprocess.run(['lscpu'],capture_output=True,text=True).stdout,gpu=subprocess.run(['nvidia-smi'],capture_output=True,text=True).stdout,memory=subprocess.run(['free','-b'],capture_output=True,text=True).stdout,note='Revision rerun host')
(o/'hardware.json').write_text(json.dumps(meta,indent=2))
def snapshot():
    zpath=r.parent/'HFL_revision_outputs.zip'
    with zipfile.ZipFile(str(zpath)+'.tmp','w',zipfile.ZIP_DEFLATED) as z:
        for p in o.glob('*'):
            if p.is_file():z.write(p,'revision_results/'+p.name)
    os.replace(str(zpath)+'.tmp',zpath)
def job(ds,m,seed,tag=''):
    suffix='_'+tag if tag else ''
    name=f'{ds}_{m}{suffix}_s{seed}'
    target=o/(name+'.json')
    if target.exists():
        v=json.loads(target.read_text())
        if len(v.get('traj',[]))==(400 if ds=='cifar' else 30):
            print('SKIP',name,flush=True);return
        raise ValueError('Incomplete existing final output '+name)
    args=[sys.executable,'run.py','--dataset',ds,'--method',m,'--seed',str(seed),'--out',str(o)]
    if tag:args+=['--tag',tag,'--fs','on' if tag=='fs' else 'off']
    print('START',name,flush=True)
    with (o/(name+'.log')).open('a') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
    if p.returncode:raise RuntimeError(name+' failed; see run log')
    print('DONE',name,flush=True);snapshot()
# First finish all paired contrasts needed for HAR statistics and Figure 3.
for seed in [42,43,44,45,46]:
    for m,tag in [('proposed','nofs'),('proposed','fs'),('fedavg',''),('powersgd','')]:job('har',m,seed,tag)
print('HAR_CONFIRMATORY_COMPLETE',flush=True)
for seed in [42,43,44,45,46]:
    for m,tag in [('proposed','nofs'),('fedavg',''),('powersgd','')]:job('fashion',m,seed,tag)
print('FASHION_CONFIRMATORY_COMPLETE',flush=True)
for ds in ['har','fashion']:
    for seed in [42,43,44,45,46]:
        for m in ['fedprox','scaffold','fednova','fedkd','qsgd','fedpaq','fedcom','topk','adaptive_topk','sign']:job(ds,m,seed)
# GPU changes arithmetic hardware only; the architecture and training budget stay fixed.
p=pathlib.Path('configs/presets.py');s=p.read_text();s=s.replace('c.feature_selection = False','c.feature_selection = False; c.cuda = True');p.write_text(s)
for seed in [42,43,44,45,46]:
    for m in ['fedavg','powersgd','qsgd','proposed']:job('cifar',m,seed)
print('ALL_REVISION_RUNS_COMPLETE',flush=True);snapshot()
