from pathlib import Path
import torch,torchvision,torchvision.transforms as T,numpy as np,random,json,hashlib,time
r=Path(__file__).parent
torch.set_num_threads(1)
t0=time.monotonic()
original=T.Compose([T.ToTensor(),T.Normalize((.4914,.4822,.4465),(.247,.2435,.2616))])
np_state=np.random.get_state();py_state=random.getstate();torch_state=torch.get_rng_state()
counts=[]
for is_train in [True,False]:
    raw=torchvision.datasets.CIFAR10(str(r/'data'),train=is_train,transform=original,download=False)
    x=torch.from_numpy(raw.data).permute(0,3,1,2).contiguous().float().div_(255.0)
    x.sub_(torch.tensor([.4914,.4822,.4465]).view(1,3,1,1)).div_(torch.tensor([.247,.2435,.2616]).view(1,3,1,1))
    for i in range(len(raw)):
        expected,y=raw[i]
        if not torch.equal(x[i],expected):raise AssertionError(('Input mismatch',is_train,i))
        if y!=raw.targets[i]:raise AssertionError('Label mismatch')
    counts.append(len(raw));del x,raw
if not torch.equal(torch_state,torch.get_rng_state()):raise AssertionError('Torch RNG changed')
now=np.random.get_state()
if not (np_state[0]==now[0] and np.array_equal(np_state[1],now[1]) and np_state[2:]==now[2:]):raise AssertionError('NumPy RNG changed')
if py_state!=random.getstate():raise AssertionError('Python RNG changed')
p=r/'flcore/data.py';s=p.read_text()
old='    return train, test, (3, 32, 32), 10'
new='    # Cache the deterministic, bitwise-verified transform once per dataset.\n    # This changes data preparation cost only; sample order and RNG are unchanged.\n    def cached(raw):\n        x = torch.from_numpy(raw.data).permute(0, 3, 1, 2).contiguous().float().div_(255.0)\n        x.sub_(torch.tensor([.4914, .4822, .4465]).view(1, 3, 1, 1))\n        x.div_(torch.tensor([.247, .2435, .2616]).view(1, 3, 1, 1))\n        ds = TensorDataset(x, torch.tensor(raw.targets, dtype=torch.long))\n        ds.targets = raw.targets\n        return ds\n    return cached(train), cached(test), (3, 32, 32), 10'
if old not in s:raise RuntimeError('Unexpected source; no edit applied')
p.write_text(s.replace(old,new))
proof=dict(verified_images=counts,all_float32_inputs_bitwise_equal=True,all_labels_equal=True,training_rng_unchanged=True,seconds=time.monotonic()-t0,data_source_md5='c58f30108f718f92721af3b95e74349a',updated_source_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(r/'cifar_input_cache_verification.json').write_text(json.dumps(proof,indent=2))
print(json.dumps(proof),flush=True)
