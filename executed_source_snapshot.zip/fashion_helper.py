import os,sys,pathlib,subprocess,json
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
r=pathlib.Path(__file__).parent;os.chdir(r)
idx=int(sys.argv[1])
methods=['fedprox','scaffold','fednova','fedkd','qsgd','fedpaq','fedcom','topk','adaptive_topk','sign']
jobs=[(seed,m) for seed in [46,45,44,43,42] for m in reversed(methods)]
for j,(seed,m) in enumerate(jobs):
    if j%2!=idx:continue
    label=f'fashion_{m}_s{seed}';target=r/'revision_results'/(label+'.json')
    if target.exists() and len(json.loads(target.read_text()).get('traj',[]))==30:continue
    print('HELPER_START',label,flush=True)
    with (r/'revision_results'/(label+'.log')).open('a') as f:
        p=subprocess.run([sys.executable,'run.py','--dataset','fashion','--method',m,'--seed',str(seed),'--out',str(r/'revision_results')],stdout=f,stderr=subprocess.STDOUT)
    if p.returncode:raise RuntimeError(label+' failed')
    print('HELPER_DONE',label,flush=True)
print('CPU_HELPER_COMPLETE',idx,flush=True)
