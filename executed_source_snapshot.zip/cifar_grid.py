import os,sys,pathlib,subprocess,json
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
r=pathlib.Path(__file__).parent;os.chdir(r)
for seed in [42,43,44,45,46]:
    for method in ['fedavg','powersgd','qsgd','proposed']:
        label=f'cifar_{method}_s{seed}'
        target=r/'revision_results'/(label+'.json')
        if target.exists() and len(json.loads(target.read_text()).get('traj',[]))==400:continue
        print('CIFAR_START',label,flush=True)
        with (r/'revision_results'/(label+'.log')).open('a') as f:
            p=subprocess.run([sys.executable,'run.py','--dataset','cifar','--method',method,'--seed',str(seed),'--out',str(r/'revision_results')],stdout=f,stderr=subprocess.STDOUT)
        if p.returncode:raise RuntimeError(label+' failed')
        print('CIFAR_DONE',label,flush=True)
print('ALL_CIFAR_COMPLETE',flush=True)
