import os, sys, subprocess, pathlib, zipfile, io, urllib.request, shutil
os.environ.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
r=pathlib.Path(__file__).parent
os.chdir(r)
subprocess.run([sys.executable,'-m','pytest','-q','tests/test_core.py'], check=True)
if not pathlib.Path('data/HAR/train/X_train.txt').exists():
    raw=urllib.request.urlopen('https://archive.ics.uci.edu/static/public/240/human+activity+recognition+using+smartphones.zip',timeout=120).read()
    dest=pathlib.Path('data/har_download');dest.mkdir(parents=True,exist_ok=True)
    zipfile.ZipFile(io.BytesIO(raw)).extractall(dest)
    for p in list(dest.rglob('*.zip')):zipfile.ZipFile(p).extractall(dest)
    src=next(dest.rglob('X_train.txt')).parent.parent
    shutil.copytree(src,'data/HAR',dirs_exist_ok=True)
for tag in ['nofs','fs']:
    target=pathlib.Path('revision_results')/('har_proposed_'+tag+'_s42.json')
    if not target.exists():
        subprocess.run([sys.executable,'run.py','--method','proposed','--dataset','har','--seed','42','--tag',tag,'--fs','on' if tag=='fs' else 'off','--out','revision_results'],check=True)
print('PAIRED_HAR_30ROUND_SEED42_COMPLETE',flush=True)
