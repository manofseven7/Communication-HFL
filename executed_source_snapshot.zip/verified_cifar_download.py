import pathlib,urllib.request,hashlib,subprocess,os,signal,time
r=pathlib.Path(__file__).parent;os.chdir(r)
url='https://zenodo.org/api/records/10089977/files/cifar-10-python.tar.gz/content'
tmp=r/'data/cifar-10-verified-mirror.tar.gz'
expected='c58f30108f718f92721af3b95e74349a'
t0=time.monotonic();h=hashlib.md5();n=0
print('MIRROR_START',url,flush=True)
with urllib.request.urlopen(url,timeout=30) as response,tmp.open('wb') as out:
    while True:
        b=response.read(1024*1024)
        if not b:break
        out.write(b);h.update(b);n+=len(b)
        if n%(10*1024*1024)==0:print('MIRROR_BYTES',n,flush=True)
        if time.monotonic()-t0>90 and n<10*1024*1024:raise RuntimeError('Mirror also too slow; original download remains active')
if h.hexdigest()!=expected:raise ValueError('Mirror checksum mismatch')
print('MIRROR_VERIFIED',n,time.monotonic()-t0,flush=True)
original=r/'data/cifar-10-python.tar.gz'
if original.exists() and hashlib.md5(original.read_bytes()).hexdigest()==expected:
    print('ORIGINAL_ALREADY_READY',flush=True)
else:
    # Only stop this notebook's own CIFAR child while it is downloading; no completed training is discarded.
    worker=int((r/'cifar.pid').read_text())
    children=subprocess.run(['pgrep','-P',str(worker)],capture_output=True,text=True).stdout.split()
    for child in children:
        cmd=pathlib.Path(f'/proc/{child}/cmdline').read_bytes()
        if b'run.py' in cmd and b'cifar' in cmd:os.kill(int(child),signal.SIGTERM)
    time.sleep(1)
    os.replace(tmp,original)
    with (r/'cifar_grid.log').open('a') as f:
        proc=subprocess.Popen([os.sys.executable,'-u','cifar_grid.py'],cwd=r,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    (r/'cifar.pid').write_text(str(proc.pid))
    print('CIFAR_RESTARTED_WITH_IDENTICAL_VERIFIED_DATA',proc.pid,flush=True)
