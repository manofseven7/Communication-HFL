from pathlib import Path
import subprocess,sys,time,os,json
r=Path(__file__).parent;os.chdir(r)
env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
idx=int(sys.argv[1])
while True:
    files=list((r/'revision_results').glob('fashion_*_s*.json'))
    complete=sum(1 for p in files if 'traj' in json.loads(p.read_text()))
    if complete>=65:break
    print('WAITING_FOR_TABULAR',complete,flush=True);time.sleep(30)
methods=['fedavg','powersgd','qsgd','proposed']
jobs=[(s,m) for s in range(42,47) for m in methods][::-1]
for seed,m in jobs[idx::3]:
    label=f'cifar_{m}_s{seed}';out=r/'revision_results'/f'{label}.json'
    if out.exists():continue
    print('GPU_HELPER_START',label,flush=True)
    with (r/'revision_results'/f'{label}.log').open('a') as f:
        p=subprocess.run([sys.executable,'-u','run.py','--dataset','cifar','--method',m,'--seed',str(seed),'--out',str(r/'revision_results')],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
    if p.returncode:raise RuntimeError(label+' failed')
    print('GPU_HELPER_DONE',label,flush=True)
print('GPU_HELPER_COMPLETE',idx,flush=True)
