from pathlib import Path
import os,sys,json,time,hashlib,resource,logging
ROOT=Path(__file__).parent;SOURCE=ROOT/'source'
sys.path.insert(0,str(SOURCE));os.chdir(SOURCE)
import numpy as np,torch
from configs.presets import preset
from flcore import utils as U,compression as C,engine as E
from flcore.methods import FLMethod
from flcore.data import make_loaders
VARIANT=sys.argv[1];SEED=int(sys.argv[2]);assert VARIANT in ['rank20','dense_down10']
os.environ.pop('HFL_DISABLE_CHECKPOINT',None)
os.environ['HFL_CHECKPOINT_SCOPE']='ablation50_v1/'+VARIANT
class AblationMethod(FLMethod):
    def __init__(self,cfg,model_template):
        super().__init__(cfg,model_template);self.audit_round=1;self.audit=[];self.context=None
    def uplink(self,upd,client_id,mask=None):
        if not all(np.isfinite(v).all() for v in upd.values()):raise FloatingPointError('Nonfinite client update '+str(client_id))
        self.context=('client0',self.audit_round) if client_id==0 else None
        result=super().uplink(upd,client_id,mask);self.context=None;return result
    def edge_aggregate(self,payloads,sizes,edge_id=None):
        self.context=('edge0',self.audit_round) if edge_id==0 else None
        result=super().edge_aggregate(payloads,sizes,edge_id);self.context=None;return result
    def central_aggregate(self,edge_payloads,edge_sizes):
        self.context=('downlink',self.audit_round)
        if self.cfg.ablation_variant=='dense_down10':
            weights=np.asarray(edge_sizes,dtype=np.float64);weights/=weights.sum();agg=None
            for wi,pay in zip(weights,edge_payloads):
                d=self._decomp(pay);agg={n:wi*d[n] for n in d} if agg is None else {n:agg[n]+wi*d[n] for n in agg}
            result=({n:('dense',v.copy()) for n,v in agg.items()},sum(v.size for v in agg.values())*U.FLOAT)
            self.server_ef=None
            if self.audit_round in [1,10,25,50]:self.audit.append(dict(stage='downlink',round=self.audit_round,relative_squared_error=0.0,compression='disabled',bytes=result[1]))
        else:result=super().central_aggregate(edge_payloads,edge_sizes)
        self.context=None;self.audit_round+=1;return result
    def apply_downlink(self,view_state,down_payload):
        result=super().apply_downlink(view_state,down_payload)
        if not all(np.isfinite(v).all() for v in result.values()):raise FloatingPointError('Nonfinite global parameters')
        return result
E.FLMethod=AblationMethod
original_compress=C.svd_compress
def monitored_compress(state,k):
    pay,nb=original_compress(state,k)
    context=current_method[0].context if current_method[0] is not None else None
    if context is not None and context[1] in [1,10,25,50]:
        reconstructed=C.svd_decompress(pay);details={};total=error=0.0
        for name,w in state.items():
            v=np.asarray(w,dtype=np.float64);delta=v-np.asarray(reconstructed[name],dtype=np.float64);den=float(np.sum(v*v));err=float(np.sum(delta*delta));total+=den;error+=err
            details[name]=dict(relative_squared_error=err/den if den else 0.0,payload=pay[name][0],shape=list(w.shape))
        current_method[0].audit.append(dict(stage=context[0],round=context[1],relative_squared_error=error/total if total else 0.0,layers=details,bytes=nb))
    return pay,nb
current_method=[None]
base_init=AblationMethod.__init__
def capture_init(self,*args,**kwargs):base_init(self,*args,**kwargs);current_method[0]=self
AblationMethod.__init__=capture_init;C.svd_compress=monitored_compress
# Capture a method restored from a checkpoint as well as a fresh method.
base_uplink=AblationMethod.uplink
def capture_uplink(self,*args,**kwargs):current_method[0]=self;return base_uplink(self,*args,**kwargs)
AblationMethod.uplink=capture_uplink
cfg=preset('cifar',fs=False);cfg.method='proposed';cfg.seed=SEED;cfg.rounds=50;cfg.rank=20 if VARIANT=='rank20' else 10;cfg.ablation_variant=VARIANT
assert torch.cuda.is_available();torch.set_num_threads(1)
U.set_seed(SEED);log=U.get_logger('ablation')
cl,tl,d,classes,is_img,idx=make_loaders('cifar',cfg.batch,SEED,cfg.alpha,cfg.clients)
partition=hashlib.sha256(b''.join(i.tobytes() for i in idx)).hexdigest()
print('TRAINING_STARTED',VARIANT,SEED,'GPU',torch.cuda.get_device_name(0),'PARTITION',partition,flush=True)
t0=time.perf_counter();traj,comm=E.train(cfg,cl,tl,d,classes,is_img,idx,log);elapsed=time.perf_counter()-t0
assert [r['round'] for r in traj]==list(range(1,51))
record=dict(variant=VARIANT,cfg=cfg.__dict__,traj=traj,final_acc=traj[-1]['acc'],final_f1=traj[-1]['f1'],comm_mib=comm.mb(),communication={k:getattr(comm,k)/1024**2 for k in ['c2e','e2c','down','setup']},wall_time_s_current_invocation=elapsed,wall_time_warning='Partial if resumed; concurrent workers; excludes data preparation; not an end-to-end network benchmark',peak_process_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,partition_sha256=partition,reconstruction_audit=current_method[0].audit)
p=ROOT/f'{VARIANT}_s{SEED}.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(record,indent=2));os.replace(tmp,p)
print('ABLATION_JOB_COMPLETE',VARIANT,SEED,record['final_acc'],record['comm_mib'],flush=True)
